The handout is cscb09-2023-5-a1.html

example.sh has sample tests
expected.txt has expected output
