#include "rect.h"

double rect_area(const rect *r)
{
  return r->w * r->h;
}
