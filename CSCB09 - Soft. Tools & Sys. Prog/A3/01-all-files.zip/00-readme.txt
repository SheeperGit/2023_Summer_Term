The handout is cscb09-2023-5-a3.html

chainpiping.c has starter code and is the file to hand in.

sample.c is a sample test case. cscb09-2023-5-a3.md is a sample file mentioned
in the handout.
