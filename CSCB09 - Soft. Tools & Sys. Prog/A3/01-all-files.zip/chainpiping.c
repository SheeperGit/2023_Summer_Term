#include "command.h"
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>

void chain_piping(const command_list *cs) {
}
