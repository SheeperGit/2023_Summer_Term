Handout: cscb09-2023-5-a4.html

Starter code, just for covering all #include's you will ever need:
hmu-client.c
hmu-server.c
hmu-helper.c

