// Client program.

#include <errno.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <signal.h>
#include <sys/socket.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

// cmdline reminder: IP-address, portnum, username, filename
int main(int argc, char *argv[]) {
  // TODO
  return 0;
}
