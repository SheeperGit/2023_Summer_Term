#ifndef _HEAPSORT_H
#define _HEAPSORT_H

int heapsort(const char *filename);

#endif
