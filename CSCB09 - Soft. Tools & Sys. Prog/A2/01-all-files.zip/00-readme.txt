The handout is cscb09-2023-5-a2.html
with introduction to heaps and heapsort in heap.pdf

heapsort.c is the file to fill in and hand in.
customer.h and heapsort.h are support header files.
sample.dat is a sample of the file format.
