import java.util.List;

public interface SortingService {
	//returns a sorted version of L without modifying L
	List<Double> sort(List<Double> L);
}
