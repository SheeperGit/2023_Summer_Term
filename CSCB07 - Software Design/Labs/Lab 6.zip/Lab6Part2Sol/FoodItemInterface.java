public interface FoodItemInterface {
	public void customize();
	public void prepare();
	public void box();
}
