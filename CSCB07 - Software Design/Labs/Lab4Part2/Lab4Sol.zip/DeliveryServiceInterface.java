
public interface DeliveryServiceInterface {
    void deliver(Item item, Customer customer);
}
