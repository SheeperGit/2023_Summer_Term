public class Customer {
	String name;
	String postalCode;
	
	public Customer(String name, String postalCode) {
		this.name = name;
		this.postalCode = postalCode;
	}

	public String getPostalCode() {
		return postalCode;
	}
}
